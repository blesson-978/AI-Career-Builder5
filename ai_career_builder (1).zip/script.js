function generateCareer() {
  const input = document.getElementById('careerInput').value.toLowerCase();
  const resultBox = document.getElementById('resultBox');

  let career = '';

  if (input.includes('code') || input.includes('developer') || input.includes('programming')) {
    career = 'Software Developer or Full Stack Engineer';
  } else if (input.includes('design')) {
    career = 'UI/UX Designer or Graphic Designer';
  } else if (input.includes('music')) {
    career = 'Music Composer or Audio Engineer';
  } else if (input.includes('ai') || input.includes('data')) {
    career = 'AI Engineer or Data Scientist';
  } else {
    career = 'Career options: Product Manager, Web Developer, or Content Creator.';
  }

  resultBox.innerHTML = `Suggested Career: <strong>${career}</strong>`;
}