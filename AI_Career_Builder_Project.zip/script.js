function findCareer() {
    const career = document.getElementById("careerInput").value.toLowerCase();
    const resultDiv = document.getElementById("result");

    if (!career) {
        resultDiv.innerHTML = "Please enter a career.";
        return;
    }

    resultDiv.innerHTML = `Analyzing career path for <strong>${career}</strong>...<br>
    - Learn top skills for ${career}<br>
    - Build portfolio projects<br>
    - Apply to internships or entry-level jobs<br>
    - Join communities for ${career}`;
}